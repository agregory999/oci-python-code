# coding: utf-8
# Copyright (c) 2016, 2023, Oracle and/or its affiliates.  All rights reserved.
# This software is dual-licensed to you under the Universal Permissive License (UPL) 1.0 as shown at https://oss.oracle.com/licenses/upl or Apache License 2.0 as shown at http://www.apache.org/licenses/LICENSE-2.0. You may choose either license.
#
# @author    : Andrew Gregory
#
# Supports Python 3
#
# DISCLAIMER – This is not an official Oracle application,  It is not supported by Oracle Support
#
# This example shows how the API can be used to build and analyze OCI Policies in a tenancy.
# The script recursively builds (and caches) a list of policy statements with provenance
# across a tenancy.  Because policies can be located in sub-compartments, it is generally harder
# to find which policies apply to a resource, a group, a compartment, and such.
# By running this script, you build a list of all statements in the tenancy, regardless of where they
# are located, and then you use the filtering commands to retrieve what you want.
# Please look at the argument parsing section or run with --help to see what is possible

from oci import config
from oci.identity import IdentityClient
from oci.identity.models import Compartment
from oci import loggingingestion

from oci import pagination
from oci.retry import DEFAULT_RETRY_STRATEGY
from oci.exceptions import ConfigFileNotFound
from oci.auth.signers import InstancePrincipalsSecurityTokenSigner
from oci.loggingingestion.models import PutLogsDetails, LogEntry, LogEntryBatch

import argparse
import json
import os
import datetime
import uuid
import logging

from policy import PolicyAnalysis
from progress import Progress

# Define Logger for module
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s [%(threadName)s] %(levelname)s %(message)s')
logger = logging.getLogger('oci-policy-analysis')

# Lists
dynamic_group_statements = []
service_statements = []
regular_statements = []
special_statements = []


########################################
# Main Code
# Pre-and Post-processing
########################################

if __name__ == "__main__":
    # Parse Arguments
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--verbose", help="increase output verbosity", action="store_true")
    parser.add_argument("-pr", "--profile", help="Config Profile, named", default="DEFAULT")
    #parser.add_argument("-o", "--ocid", help="OCID of compartment (if not passed, will use tenancy OCID from profile)", default="TENANCY")
    parser.add_argument("-sf", "--subjectfilter", help="Filter all statement subjects by this text")
    parser.add_argument("-vf", "--verbfilter", help="Filter all verbs (inspect,read,use,manage) by this text")
    parser.add_argument("-rf", "--resourcefilter", help="Filter all resource (eg database or stream-family etc) subjects by this text")
    parser.add_argument("-lf", "--locationfilter", help="Filter all location (eg compartment name) subjects by this text")
    parser.add_argument("-r", "--recurse", help="Recursion or not (default True)", action="store_true")
    parser.add_argument("-c", "--usecache", help="Load from local cache (if it exists)", action="store_true")
    parser.add_argument("-w", "--writejson", help="Write filtered output to JSON", action="store_true")
    parser.add_argument("-ip", "--instanceprincipal", help="Use Instance Principal Auth - negates --profile", action="store_true")
    parser.add_argument("-lo", "--logocid", help="Use an OCI Log - provide OCID")
    parser.add_argument("-t", "--threads", help="Concurrent Threads (def=5)", type=int, default=1)
    args = parser.parse_args()
    verbose = args.verbose
    use_cache = args.usecache
    #ocid = args.ocid
    profile = args.profile
    threads = args.threads
    sub_filter = args.subjectfilter
    verb_filter = args.verbfilter
    resource_filter = args.resourcefilter
    location_filter = args.locationfilter
    recursion = args.recurse
    write_json_output = args.writejson
    use_instance_principals = args.instanceprincipal
    log_ocid = None if not args.logocid else args.logocid

    # Update Logging Level
    if verbose:
        logger.setLevel(logging.DEBUG)
        logging.getLogger('oci._vendor.urllib3.connectionpool').setLevel(logging.INFO)

    logger.info(f'Using {"profile" + profile if not use_instance_principals else "instance principals"} with Logging level {"DEBUG" if verbose else "INFO"}')

    # Create the class
    policy_analysis = PolicyAnalysis(progress=None, 
                                     profile=profile,
                                     use_instance_principal=use_instance_principals,
                                     use_cache=use_cache,
                                     use_recursion=recursion,
                                     verbose=verbose)

    # Instruct it to do stuff
    policy_analysis.initialize_client()

    policy_analysis.load_policies_from_client(use_cache=use_cache,
                                              use_recursion=recursion)
    
    exit(1)
    # Perform Filtering
    if sub_filter:
        logger.info(f"Filtering subject: {sub_filter}. Before: {len(dynamic_group_statements)}/{len(service_statements)}/{len(regular_statements)} DG/SVC/Reg statements")
        dynamic_group_statements = list(filter(lambda statement: sub_filter.casefold() in statement[0].casefold(), dynamic_group_statements))
        service_statements = list(filter(lambda statement: sub_filter.casefold() in statement[0].casefold(), service_statements))
        regular_statements = list(filter(lambda statement: sub_filter.casefold() in statement[0].casefold(), regular_statements))
        logger.info(f"After: {len(dynamic_group_statements)}/{len(service_statements)}/{len(regular_statements)} DG/SVC/Reg statements")

    if verb_filter:
        logger.info(f"Filtering verb: {verb_filter}. Before: {len(dynamic_group_statements)}/{len(service_statements)}/{len(regular_statements)} DG/SVC/Reg statements")
        dynamic_group_statements = list(filter(lambda statement: verb_filter.casefold() in statement[1].casefold(), dynamic_group_statements))
        service_statements = list(filter(lambda statement: verb_filter.casefold() in statement[1].casefold(), service_statements))
        regular_statements = list(filter(lambda statement: verb_filter.casefold() in statement[1].casefold(), regular_statements))
        logger.info(f"After: {len(dynamic_group_statements)}/{len(service_statements)}/{len(regular_statements)} DG/SVC/Reg statements")

    if resource_filter:
        logger.info(f"Filtering resource: {resource_filter}. Before: {len(dynamic_group_statements)}/{len(service_statements)}/{len(regular_statements)} DG/SVC/Reg statements")
        dynamic_group_statements = list(filter(lambda statement: resource_filter.casefold() in statement[2].casefold(), dynamic_group_statements))
        service_statements = list(filter(lambda statement: resource_filter.casefold() in statement[2].casefold(), service_statements))
        regular_statements = list(filter(lambda statement: resource_filter.casefold() in statement[2].casefold(), regular_statements))
        logger.info(f"After: {len(dynamic_group_statements)}/{len(service_statements)}/{len(regular_statements)} DG/SVC/Reg statements")

    if location_filter:
        logger.info(f"Filtering location: {location_filter}. Before: {len(dynamic_group_statements)}/{len(service_statements)}/{len(regular_statements)} DG/SVC/Reg statements")
        dynamic_group_statements = list(filter(lambda statement: location_filter.casefold() in statement[3].casefold(), dynamic_group_statements))
        service_statements = list(filter(lambda statement: location_filter.casefold() in statement[3].casefold(), service_statements))
        regular_statements = list(filter(lambda statement: location_filter.casefold() in statement[3].casefold(), regular_statements))
        logger.info(f"After: {len(dynamic_group_statements)}/{len(service_statements)}/{len(regular_statements)} DG/SVC/Reg statements")

    # Print Special
    entries = []
    logger.info("========Summary Special==============")
    for index, statement in enumerate(special_statements, start=1):
        logger.info(f"Statement #{index}: {statement[0]} | Policy: {statement[2]}")
        entries.append(LogEntry(id=str(uuid.uuid1()),
                                data=f"Statement #{index}: {statement}"))
    logger.info(f"Total Special statement in tenancy: {len(special_statements)}")

    # Create Log Batch
    special_batch = LogEntryBatch(defaultlogentrytime=datetime.datetime.utcnow(),
                                  source="oci-policy-analysis",
                                  type="special-statement",
                                  entries=entries)

    # Print Dynamic Groups
    entries = []
    logger.info("========Summary DG==============")
    for index, statement in enumerate(dynamic_group_statements, start=1):
        logger.info(f"Statement #{index}: {statement[9]} | Policy: {statement[5]}/{statement[6]}")
        entries.append(LogEntry(id=str(uuid.uuid1()),
                                data=f"Statement #{index}: {statement[9]} | Policy: {statement[5]}/{statement[6]}"))
    logger.info(f"Total Service statement in tenancy: {len(dynamic_group_statements)}")

    # Create Log Batch
    dg_batch = LogEntryBatch(defaultlogentrytime=datetime.datetime.utcnow(),
                             source="oci-policy-analysis",
                             type="dynamic-group-statement",
                             entries=entries)

    # Print Service
    entries = []
    logger.info("========Summary SVC==============")
    for index, statement in enumerate(service_statements, start=1):
        logger.info(f"Statement #{index}: {statement[9]} | Policy: {statement[5]}/{statement[6]}")
        entries.append(LogEntry(id=str(uuid.uuid1()),
                                data=f"Statement #{index}: {statement[9]} | Policy: {statement[5]}/{statement[6]}"))
    logger.info(f"Total Service statement in tenancy: {len(service_statements)}")

    # Create Log Batch
    service_batch = LogEntryBatch(defaultlogentrytime=datetime.datetime.utcnow(),
                                  source="oci-policy-analysis",
                                  type="service-statement",
                                  entries=entries)

    # Print Regular
    entries = []
    logger.info("========Summary Reg==============")
    for index, statement in enumerate(regular_statements, start=1):
        logger.info(f"Statement #{index}: {statement[9]} | Policy: {statement[5]}{statement[6]}")
        entries.append(LogEntry(id=str(uuid.uuid1()),
                                data=f"Statement #{index}: {statement[9]} | Policy: {statement[5]}{statement[6]}"))
    logger.info(f"Total Regular statements in tenancy: {len(regular_statements)}")

    # Create Log Batch
    regular_batch = LogEntryBatch(defaultlogentrytime=datetime.datetime.now(datetime.timezone.utc),
                                  source="oci-policy-analysis",
                                  type="regular-statement",
                                  entries=entries)

    # Write batches to OCI Logging
    if log_ocid:
        put_logs_response = loggingingestion_client.put_logs(
            log_id=log_ocid,
            put_logs_details=PutLogsDetails(
                specversion="1.0",
                log_entry_batches=[special_batch, dg_batch, service_batch, regular_batch]
            )
        )

    # To output file if required
    if write_json_output:
        # Empty Dictionary
        statements_list = []
        for i, s in enumerate(special_statements):
            statements_list.append({"type": "special", "statement": s[0],
                                    "lineage": {"policy-compartment-ocid": s[4], "policy-relative-hierarchy": s[1],
                                                "policy-name": s[2], "policy-ocid": s[3]}
                                    })
        for i, s in enumerate(dynamic_group_statements):
            statements_list.append({"type": "dynamic-group", "subject": s[0], "verb": s[1],
                                    "resource": s[2], "location": s[3], "conditions": s[4],
                                    "lineage": {"policy-compartment-ocid": s[8], "policy-relative-hierarchy": s[5],
                                                "policy-name": s[6], "policy-ocid": s[7], "policy-text": s[9]}
                                    })
        for i, s in enumerate(service_statements):
            statements_list.append({"type": "service", "subject": s[0], "verb": s[1],
                                    "resource": s[2], "location": s[3], "conditions": s[4],
                                    "lineage": {"policy-compartment-ocid": s[8], "policy-relative-hierarchy": s[5],
                                                "policy-name": s[6], "policy-ocid": s[7], "policy-text": s[9]}
                                    })
        for i, s in enumerate(regular_statements):
            statements_list.append({"type": "regular", "subject": s[0], "verb": s[1],
                                    "resource": s[2], "location": s[3], "conditions": s[4],
                                    "lineage": {"policy-compartment-ocid": s[8], "policy-relative-hierarchy": s[5],
                                                "policy-name": s[6], "policy-ocid": s[7], "policy-text": s[9]}
                                    })
        # Serializing json
        json_object = json.dumps(statements_list, indent=2)

        # Writing to sample.json
        with open(f"policyoutput-{tenancy_ocid}.json", "w") as outfile:
            outfile.write(json_object)
    logger.debug(f"-----Complete--------")